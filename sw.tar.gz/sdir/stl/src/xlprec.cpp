// Copyright (c) Microsoft Corporation.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

// _LXp* functions

#include "xxlftype.hpp"
#include "xxxprec.hpp"
